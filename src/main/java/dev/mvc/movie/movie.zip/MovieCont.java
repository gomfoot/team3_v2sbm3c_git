package dev.mvc.movie;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import dev.mvc.mgenre.MgenreProcInter;
import dev.mvc.mgenre.MgenreVO;

@Controller
public class MovieCont {
  @Autowired
  @Qualifier("dev.mvc.mgenre.MgenreProc")
  private MgenreProcInter mgenreProc;
  
  @Autowired
  @Qualifier("dev.mvc.movie.MovieProc")
  private MovieProcInter movieProc;
  
  public MovieCont() {
    System.out.println("-> MovieCont created.");
  }

  /**
   * 새로고침 방지
   * @return
   */
  @RequestMapping(value="/movie/msg.do", method=RequestMethod.GET)
  public ModelAndView msg(String url){
    ModelAndView mav = new ModelAndView();

    mav.setViewName(url); // forward
    
    return mav; // forward
  }
        
  /**
   * 목록 + 검색 + 페이징 지원
   * http://localhost:9091/movie/list_search_grid.do?mgenreno=1&word=스위스&now_page=1
   * 
   * @param mgenreno
   * @param word
   * @param now_page
   * @return
   */
  @RequestMapping(value = "/movie/list_search_grid.do", method = RequestMethod.GET)
  public ModelAndView list_search_grid(
      @RequestParam(value = "mgenreno", defaultValue = "1") int mgenreno,
      @RequestParam(value = "word", defaultValue = "") String word,
      @RequestParam(value = "now_page", defaultValue = "1") int now_page,
      HttpServletRequest request) {
    System.out.println("-> list_search_grid now_page: " + now_page);

    ModelAndView mav = new ModelAndView();

    // 숫자와 문자열 타입을 저장해야함으로 Obejct 사용
    HashMap<String, Object> map = new HashMap<String, Object>();
    map.put("mgenreno", mgenreno); // #{mgenreno}
    map.put("word", word); // #{word}
    map.put("now_page", now_page); // 페이지에 출력할 레코드의 범위를 산출하기위해 사용
    
    // 검색 목록
    List<MovieVO> list = movieProc.list_search_grid(map);
    mav.addObject("list", list);
    System.out.println("cnffur: " + mgenreno + word + now_page);
    //List<MovieVO> list = this.movieProc.list_by_mgenreno(mgenreno);
    //mav.addObject("list", list);
    
    // 검색된 레코드 갯수
    int search_count = movieProc.search_count(map);
    mav.addObject("search_count", search_count);

    MgenreVO mgenreVO = mgenreProc.read(mgenreno);
    mav.addObject("mgenreVO", mgenreVO);


    /*
     * SPAN태그를 이용한 박스 모델의 지원, 1 페이지부터 시작 현재 페이지: 11 / 22 [이전] 11 12 13 14 15 16 17
     * 18 19 20 [다음]
     * @param list_file 목록 파일명
     * @param mgenreno 카테고리번호
     * @param search_count 검색(전체) 레코드수
     * @param now_page 현재 페이지
     * @param word 검색어
     * @return 페이징 생성 문자열
     */
    String paging = movieProc.pagingBox("list_search_grid.do", mgenreno, search_count, now_page, word);
    mav.addObject("paging", paging);

    mav.addObject("now_page", now_page);

    mav.setViewName("/movie/list_search_grid");

    return mav;
  }
   
 
  //http://localhost:9091/movie/read.do
  /**
   * 조회
   * @return
   */
  @RequestMapping(value="/movie/read.do", method=RequestMethod.GET )
  public ModelAndView read(HttpServletRequest request, int movieno) {
    // public ModelAndView read(int movieno, int now_page) {
    // System.out.println("-> now_page: " + now_page);
    
    ModelAndView mav = new ModelAndView();

    MovieVO movieVO = this.movieProc.read(movieno);
    mav.addObject("movieVO", movieVO); // request.setAttribute("movieVO", movieVO);

    MgenreVO mgenreVO = this.mgenreProc.read(movieVO.getMgenreno());
    mav.addObject("mgenreVO", mgenreVO);  
    
    mav.setViewName("/movie/read"); // /WEB-INF/views/movie/read.jsp
    
    return mav;
  }
  
  
}


