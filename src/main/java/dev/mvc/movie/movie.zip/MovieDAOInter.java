package dev.mvc.movie;

import java.util.HashMap;
import java.util.List;

public interface MovieDAOInter {
  /**
   * 특정 그룹에 속한 레코드 갯수 산출
   * @param mgenreno
   * @return
   */
  public int count_by_mgenreno(int mgenreno);
  
  /**
   * 검색 + 페이징 목록
   * @param map
   * @return
   */
  public List<MovieVO> list_search_grid(HashMap<String, Object> map);
  
  /**
   * 조회
   * @param movieno
   * @return
   */
  public MovieVO read(int movieno);
  
  /**
   * 장르별 검색 레코드 갯수
   * @param hashMap
   * @return
   */
  public int search_count(HashMap<String, Object> hashMap);
}